### Sentinel

```shell
docker-compose -f docker-compose-sentinel.yml -p sentinel up -d
```

访问地址：[`http://127.0.0.1:8858`](http://127.0.0.1:8858)
登录账号密码：`sentinel/sentinel`
