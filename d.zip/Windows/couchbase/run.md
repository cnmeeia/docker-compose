### Couchbase

```shell
docker-compose -f docker-compose-couchbase.yml -p couchbase up -d
```

管理平台地址：[`http://127.0.0.1:8091`](http://127.0.0.1:8091)
默认登录账号密码：`Administrator/password`