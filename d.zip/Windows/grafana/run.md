### Grafana - 开源数据可视化工具(数据监控、数据统计、警报)

```shell
docker-compose -f docker-compose-grafana.yml -p grafana up -d
```

访问地址：[`http://127.0.0.1:3000`](http://127.0.0.1:3000)
默认登录账号密码：`admin/admin`