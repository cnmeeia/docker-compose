### BaiduPCS-Web

```shell
docker-compose -f docker-compose-baidupcs-web.yml -p baidupcs-web up -d
```

访问地址：[`http://127.0.0.1:5299`](http://127.0.0.1:5299)
