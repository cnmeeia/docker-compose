### Kafka

```shell
docker-compose -f docker-compose-kafka.yml -p kafka up -d
```

集群管理地址：[`http://127.0.0.1:9001`](http://127.0.0.1:9001)
