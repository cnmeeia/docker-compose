### Jenkins

```shell
docker-compose -f docker-compose-jenkins.yml -p jenkins up -d
```

访问地址：[`http://127.0.0.1:8080`](http://127.0.0.1:8080)
