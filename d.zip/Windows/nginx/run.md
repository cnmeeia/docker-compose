### Nginx

```shell
docker-compose -f docker-compose-nginx.yml -p nginx up -d
```

访问地址：[`http://127.0.0.1/`](http://127.0.0.1/)
