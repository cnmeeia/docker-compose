### MinIO

```shell
docker-compose -f docker-compose-minio.yml -p minio up -d
```

访问地址：[`http://127.0.0.1:9001/minio`](http://127.0.0.1:9001/minio)
登录账号密码：`root/password`
