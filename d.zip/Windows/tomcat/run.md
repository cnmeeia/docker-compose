### Tomcat

```shell
docker-compose -f docker-compose-tomcat.yml -p tomcat up -d
```

访问地址：[`http://127.0.0.1:8081`](http://127.0.0.1:8081)
