### RabbitMQ

```shell
docker-compose -f docker-compose-rabbitmq.yml -p rabbitmq up -d
```

web管理端：[`http://127.0.0.1:15672`](http://127.0.0.1:15672)
登录账号密码：`admin/admin`