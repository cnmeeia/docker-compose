### Grafana Loki - 一个水平可扩展，高可用性，多租户的日志聚合系统

```shell
docker-compose -f docker-compose-grafana-promtail-loki.yml -p grafana_promtail_loki up -d
```

访问地址：[`http://127.0.0.1:3000`](http://127.0.0.1:3000)
默认登录账号密码：`admin/admin`