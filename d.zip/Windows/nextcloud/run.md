### Nextcloud - 多端同步网盘

```shell
docker-compose -f docker-compose-nextcloud.yml -p nextcloud up -d
```

访问地址：[`http://127.0.0.1:81`](http://127.0.0.1:81) , 创建管理员账号
