# Windows使用Docker安装开发环境系列

## Docker安装

[https://zhengqing.blog.csdn.net/article/details/103441358](https://zhengqing.blog.csdn.net/article/details/103441358)

## 安装开发环境系列

### 环境准备

> 注：建议使用`Git Bash Here`执行以下命令

```shell script
# 创建文件夹
mkdir -p E:/zhengqingya/soft/soft-dev/Docker
cd E:/zhengqingya/soft/soft-dev/Docker
```
