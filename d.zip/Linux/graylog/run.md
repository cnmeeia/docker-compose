### Graylog - 日志管理工具

```shell
docker-compose -f docker-compose-graylog.yml -p graylog_demo up -d
```

访问地址：[`http://ip地址:9001`](http://www.zhengqingya.com:9001)
默认登录账号密码：`admin/admin`