### XXL-JOB - 分布式任务调度平台

```shell
docker-compose -f docker-compose-xxl-job.yml -p xxl-job up -d
```

访问地址：[`http://ip地址:9003/xxl-job-admin`](http://www.zhengqingya.com:9003/xxl-job-admin)
默认登录账号密码：`admin/123456`
