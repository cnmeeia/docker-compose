### ActiveMQ

```shell
docker-compose -f docker-compose-activemq.yml -p activemq up -d
```

访问地址：[`ip地址:8161`](http://www.zhengqingya.com:8161)
登录账号密码：`admin/admin`