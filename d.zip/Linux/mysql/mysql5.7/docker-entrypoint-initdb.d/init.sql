SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 创建数据库
create database zq;


SET FOREIGN_KEY_CHECKS = 1;