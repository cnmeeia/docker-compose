### Filebeat

> 轻量型日志采集器，可以将指定日志转发到Logstash、Elasticsearch、Kafka、Redis等中。

```shell
docker-compose -f docker-compose-filebeat.yml -p filebeat up -d
```
