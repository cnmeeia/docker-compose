### GitLab

```shell
docker-compose -f docker-compose-gitlab.yml -p gitlab up -d
```

访问地址：[`ip地址:10080`](http://www.zhengqingya.com:10080)
默认root账号，密码访问页面时需自己设置