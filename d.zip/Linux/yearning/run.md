### Yearning

```shell
docker-compose -f docker-compose-yearning.yml -p yearning up -d
```

访问地址：[`ip地址:8000`](http://www.zhengqingya.com:8000)
默认登录账号密码：`admin/Yearning_admin`