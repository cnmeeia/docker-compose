### MongoDB - 基于文档的通用分布式数据库

```shell
docker-compose -f docker-compose-mongodb.yml -p mongodb up -d
```

访问地址：[`http://ip地址:1234`](http://www.zhengqingya.com:1234)
Connection string：`mongodb://admin:123456@ip地址:27017`