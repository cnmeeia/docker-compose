# grafana loki demo

> 参考：[https://github.com/rongfengliang/grafana-loki-demo](https://github.com/rongfengliang/grafana-loki-demo)

# run

```shell script
docker-compose build
docker-compose -f docker-compose.yml -p grafana_promtail_loki_nginx_demo up -d
```
