#!/bin/sh
nohup /usr/bin/promtail -config.file=/etc/promtail/promtail-docker-config2.yaml & 