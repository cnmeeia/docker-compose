### Portainer

> docker可视化管理界面工具

```shell
docker-compose -f docker-compose-portainer.yml -p portainer up -d

# -p：项目名称
# -f：指定docker-compose.yml文件路径
# -d：后台启动
```

访问地址：[`ip地址:9000`](http://www.zhengqingya.com:9000)
