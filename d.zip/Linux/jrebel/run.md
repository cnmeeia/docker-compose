### Jrebel

```shell
docker-compose -f docker-compose-jrebel.yml -p jrebel up -d
```

默认反代`idea.lanyus.com`, 运行起来后

1. 激活地址： `http://ip地址:8888/UUID` -> tips: [UUID在线生成](https://www.guidgen.com)
2. 邮箱随意填写