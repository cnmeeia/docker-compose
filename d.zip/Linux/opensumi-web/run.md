### OpenSumi

一款帮助你快速搭建本地和云端 IDE 的框架。

```shell
docker-compose -f docker-compose-opensumi-web.yml -p opensumi-web up -d
```

访问地址：[`http://ip地址:20000`](http://www.zhengqingya.com:20000)
