### Couchbase

```shell
docker-compose -f docker-compose-couchbase.yml -p couchbase up -d
```

管理平台地址：[`ip地址:8091`](http://www.zhengqingya.com:8091)
默认登录账号密码：`Administrator/password`
