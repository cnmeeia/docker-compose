package com.zhengqing.testdockerjar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDockerJarApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestDockerJarApplication.class, args);
    }

}
